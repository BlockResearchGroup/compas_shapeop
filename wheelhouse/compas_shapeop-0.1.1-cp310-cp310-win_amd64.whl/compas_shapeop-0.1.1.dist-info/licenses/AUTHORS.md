# Credits

## COMPAS ShapeOp Python Package

### Main Developers

- Petras Vestartas <<petrasvestartas@gmail.com>> [@petrasvestartas](https://github.com/petrasvestartas)
- Tom Van Mele <<tom.v.mele@gmail.com>> [@brgcode](https://github.com/brgcode), [@tomvanmele](https://github.com/tomvanmele)

### ShapeOp Authors from GCM, EPFL
- Sofien Bouaziz <<sofien.bouaziz@gmail.com>> [@sofienbouaziz](https://github.com/sofienbouaziz)